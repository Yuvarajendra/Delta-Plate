
%% Post-Processing of Force Measurements, TMMV01. 
%
% The file can - after additional implementation - be used to post-process
% data from the water tunnel measurements of the normal force on a delta 
% plate. The sampling frequency is 1 kHz.
%
% Complete this file by calculating normal force for each AoA.


%%
close all
clc
clear all

% Number of samples
N_samples = 1000;

% AoA range
aoa_i=4;   % Initial AoA
aoa_f=60;  % Final AoA
daoa =4;  % AoA step
j=1;

%% Read raw data 
load('delta.mat')


%% Plot of measured signals
t=.001:.001:1;

scrsz = get(0,'ScreenSize');
figure('Position',[200 200 scrsz(3)/3 scrsz(3)/4]) 
plot(t,Normal(:,1),'r-',t,Normal(:,15),'b-', ...
     t,Normal0(:,1),'r:',t,Normal0(:,15),'b:');
 legend('N \alpha=4^{\circ}','N \alpha=60^{\circ}','N0 \alpha=4^{\circ}','N0 \alpha=60^{\circ}')
title('Normal Force...');
xlabel('Time [s]');
ylabel('Normal Force [N]');
 
%% Calculation the normal force and coefficient


%% Calculation of the theoretical lift 


%% Plot the results
